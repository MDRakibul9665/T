# Ubuntu RDP  


This is just for Testing and Deployment of Applications, and Debugging Purpose. I do not encourage to misuse of Github Actions! **I am not respossible if your  account gets banned!**
</br>


# Things Required

 1. *Github account*
 2. *Google account*
 3. **Brain!**
## Steps

 1. *Fork this repo to your github account* 
  <br/>

   ![fork github](/img/fork.png)
   
 2. Go to [https://remotedesktop.google.com/headless](https://remotedesktop.google.com/headless) and press begin


 ![fork github](/img/begin.png)
 
> (Optional  step : You can download  the Chrome remote desktop or
> chrome extension to use it  in 
>     as a application in your system or browser alternatively you can use the rdp on  any broswer too!)
 
  <br/>

  3. Press next and click on Authorize .

  ![fork github](/img/next.png)
  <br/>

  ![fork github](/img/auth.png)
  <br/>

 4. Continue with your Google account and grant the premissions.

 ![fork github](/img/google.png)
 <br/>
   
 5. Now you will end on the final page **Copy the code of Ubuntu ** [*Tested Ubuntu* ].

 ![fork github](/img/final.png)
 <br/>
   
 6. Goto your Github account and  ***open the repository which you forked*** , ( *That is  your username/ubunturdp*)

 7. Now click on actions and under all work flows select ubunturdp

 ![fork github](/img/actions.png)

> **Important step**

8.  Click Run workflow and paste the copied code earlier to  *paste your code here* box and click  **Run Workflow**

 ![fork github](/img/paste.png)
   <br/>

09. Wait for a while (will take minimum 5mins and avg 10mins).

    
  <img src="/img/cancel.png" title="ubuntu">



10.  Go to  [https://remotedesktop.google.com/access/](https://remotedesktop.google.com/access/)  to access your RDP. Pin is **123456**

 ![fork github](/img/best.png)
   <br/>

11.  Your RDP on browser is ready !

    
  <img src="/img/ub.png" title="ubuntu">


 
# Default PIN is 123456

> Dont forget to star the repo and follow me ! Thank you
